#!/bin/bash

rm -r classes/GUI
rm -r classes/server
rm -r classes/client
rm -r classes/database
