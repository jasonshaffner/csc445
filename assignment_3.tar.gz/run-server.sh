#!/bin/bash

cd classes/
java server.Server
