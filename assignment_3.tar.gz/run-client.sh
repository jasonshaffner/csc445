#!/bin/bash

cd classes
appletviewer -J-Djava.security.policy=polfile index.html
